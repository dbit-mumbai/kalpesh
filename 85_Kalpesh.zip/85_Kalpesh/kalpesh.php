<!DOCTYPE html>
<html>
<head>
<body style="background-color:#6a1b9a;">
  
 <script>
 function abc(){
   var x=document.myForm.fname;
   if(x.value == ""){
   alert("lab name cannot be empty");
   return false;
 }
	if (! allLetter(x)) {
  		alert("Enter valid lab name");
  		 return false;
	}
   var y=document.myForm.num;
   if(y.value == ""){
   	alert("lab no cannot be empty");
  	 return false;
   }
	if (! allnumeric(y)) {
		 alert('Enter valid lab no');
      return false;
	}	
  var z=document.myForm.kal;
   if(z.value == ""){
   alert("lab incharge cannot be empty");
   return false;
   }
  if (! allLetter(z)) {
  		alert("Enter valid lab incharge name");
  		 return false;
	}
   var a=document.myForm.con;
   if(a.value == ""){
   alert("contact cannot be empty");
   return false;
   }
if (! allnumeric(a)) {
		 alert('Enter valid contact no');
      return false;
	}

   var b=document.myForm.pr;
   if(b.value == ""){
   alert("experiment cannot be empty");
   return false;
   }
if (! allnumeric(b)) {
		 alert('Enter valid exp no');
      return false;
	}
   var c=document.myForm.tr;
   if(c.value == ""){
   alert("training cannot be empty");
   return false;
   }  
if (! allnumeric(c)) {
		 alert('Enter valid training days');
      return false;
	}
    
   var d=document.myForm.di;
   if(d.value == ""){
   alert("dimension cannot be empty");
   return false;
   }
if (! allnumeric(d)) {
		 alert('Enter valid dimension');
      return false;
	}
   var e=document.myForm.co;
   if(e.value == ""){
   alert("no. of computers cannot be empty");
   return false;
   }

if (! allnumeric(e)) {
		 alert('Enter valid no of computers');
      return false;
	}
   var f=document.myForm.fu;
   if(f.value == ""){
   alert("furniture cannot be empty");
   return false;
   } 
if (! allnumeric(f)) {
		 alert('Enter no of furnitures');
      return false;
	}
   var g=document.myForm.yp;
   if(g.value == ""){
   alert("year of purchase cannot be empty");
   return false;
   } 

   var h=document.myForm.cp;
   if(h.value == ""){
   alert("cost of purchase cannot be empty");
   return false;
   } 
if (! allnumeric(h)) {
		 alert('Enter valid cost');
      return false;
	}
   var i=document.myForm.pc;
   if(i.value == ""){
   alert("pc model cannot be empty");
   return false;
   } 

   var j=document.myForm.prh;
   if(j.value == ""){
   alert("P.R.H. cannot be empty");
   return false;
   } 

if (! allnumeric(j)) {
		 alert('Enter valid specifications');
      return false;
	}
   var k=document.myForm.os;
   if(k.value == ""){
   alert("o.s. cannot be empty");
   return false;
   } 

   var l=document.myForm.as;
   if(l.value == ""){
   alert("application software cannot be empty");
   return false;
   } 
if (! allLetter(l)) {
  		alert("Enter valid software name");
  		 return false;
	}

   var m=document.myForm.db;
   if(m.value == ""){
   alert("database cannot be empty");
   return false;
   } 
if (! allLetter(m)) {
  		alert("Enter valid database");
  		 return false;
	}

 var n=document.myForm.av;
   if(n.value == ""){
   alert("anti-virus cannot be empty");
   return false;
   } 
if (! allLetter(n)) {
  		alert("Enter valid anti virus");
  		 return false;
	}
   var o=document.myForm.ic;
   if(o.value == ""){
   alert("internet connectivity cannot be empty");
   return false;
   } 
if (! allLetter(o)) {
  		alert("Enter connectivity yes/no");
  		 return false;
	}

   var p=document.myForm.ar;
   if(p.value == ""){
   alert("adressing range cannot be empty");
   return false;
   } 

 var q=document.myForm.rss;
   if(q.value == ""){
   alert("router/switch specs. cannot be empty");
   return false;
   } 


 var r=document.myForm.ptr;
   if(r.value == ""){
   alert("projector info cannot be empty");
   return false;
   } 
if (! allLetter(r)) {
  		alert(" projector supported yes/no");
  		 return false;
	}

   var s=document.myForm.cc;
   if(s.value == ""){
   alert("cctv info cannot be empty");
   return false;
   } 

if (! allLetter(s)) {
  		alert("Enter yes/no");
  		 return false;
	}

   var t=document.myForm.cc;
   if(t.value == ""){
   alert("cctv info cannot be empty");
   return false;
   } 

if (! allLetter(t)) {
  		alert("Enter cctv supported yes/no");
  		 return false;
	}
var w=document.myForm.ak;
   if(w.value == ""){
   alert("AC info cannot be empty");
   return false;
   } 

if (! allLetter(w)) {
  		alert("AC yes/no");
  		 return false;
	}
   var u=document.myForm.pi;
   if(u.value == ""){
   alert("printer info cannot be empty");
   return false;
   } 

if (! allLetter(u)) {
  		alert("Enter  printer supported yes/no");
  		 return false;
	}

   var v=document.myForm.fe;
   if(v.value == ""){
   alert("fire extenguisher info cannot be empty");
   return false;
   } 
if (! allLetter(v)) {
  		alert("fire extenguisher yes/no");
  		




   }

}   

 function allLetter(inputtxt)
                {
                 var letters = /^[A-Za-z]+$/;
                 if(inputtxt.value.match(letters))
                   {
              	     return true;
                   }
                 else
                   {
              	     return false;
                   }
                }
 function allnumeric(inputtxt)
               {
                  var numbers = /^[0-9]+$/;
                  if(inputtxt.value.match(numbers))
                  {
                    return true;
                  }
                  else
                  {
                    return false;
                  }
               }

</script>
   <center><h1><font color="gold">DON BOSCO INSTITUTE OF TECHNOLOGY</h1></font></center>
   <center><h2><font color="gold">DEPARTMENT OF INFORMATION TECHNOLOGY</h2></font></center>
 <center>
 <form name="myForm" onsubmit="return abc()" method="post">
    <th>Lab name: <input type="text" name="fname">
  Lab no: <input type="text" name="num"><br></th>
  <table width="50%" border="2">
   <tr >
     <th bgcolor="FFFF00" colspan='3'>Laboratory In-Charge:</th> 
   </tr>
   <tr>
     <th>Name of Lab In-Charge </th> <td>:</td> <td><input type="text" name="kal"></td> 
   </tr>
   <tr>
     <th>Extension/Contact: </th> <td>:</td> <td><input type="text" name="con"></td>
   </tr>
   <tr>
     <th bgcolor="FFFF00" colspan='3'>Lab Utilization:</th> 
   </tr>
    <tr>
     <th>Practical/Experiments</th> <td>:</td><td><input type="text" name="pr"></td>
   </tr>
    <tr>
     <th>Training/Workshop/Seminar</th><td>:</td><td><input type="text" name="tr"></td> 
   </tr>
   <tr>
     <th bgcolor="FFFF00" colspan='3'>Laboratory Area/No. Of PCs:</th> 
   </tr>
    <tr>
     <th>Dimension</th><td>:</td><td><input type="text" name="di"></td> 
   </tr>
    <tr>
     <th>No. of Computers</th><td>:</td><td><input type="text" name="co"></td> 
   </tr>
    <tr>
     <th>Furniture</th><td>:</td><td><input type="text" name="fu"></td> 
   </tr>
    <tr>
     <th bgcolor="FFFF00" colspan='3'>Additional:</th> 
   </tr>
      <tr>
     <th>Year Of Purchase</th><td>:</td><td><input type="date" name="yp"></td> 
   </tr>
      <tr>
     <th>Cost of Purchase</th><td>:</td><td><input type="text" name="cp"></td> 
   </tr>
  <tr>
     <th bgcolor="FFFF00" colspan='3'>Hardware Summary:</th> 
   </tr>
    <tr>
     <th>PC Model/Make</th><td>:</td><td><input type="text" name="pc"></td> 
   </tr>
    <tr>
     <th>Procesor,RAM,HDD</th><td>:</td><td><input type="text" name="prh"></td> 
   </tr>
   <tr>
     <th bgcolor="FFFF00" colspan='3'>Key Software Summary:</th> 
   </tr>
    <tr>
     <th>Opertaing System(s)</th><td>:</td><td><input type="text" name="os"></td> 
   </tr>
   <tr>
     <th>Application Software(s)</th><td>:</td><td><input type="text" name="as"></td> 
   </tr>
    <tr>
     <th>Database(s)</th><td>:</td><td><input type="text" name="db"></td> 
   </tr>
    <tr>
     <th>Anti-virus</th><td>:</td><td><input type="text" name="av"></td> 
   </tr>
   <tr>
     <th bgcolor="FFFF00" colspan='3'>Network/Internet:</th> 
   </tr>
    <tr>
     <th>Internet Connectivity</th><td>:</td><td><input type="text" name="ic"></td> 
   </tr>
   <tr>
     <th>LAN:IP Addressing Range</th><td>:</td><td><input type="text" name="ar"></td>
   </tr>
    <tr>
     <th>Router/Switch Specification</th><td>:</td><td><input type="text" name="rss"></td> 
   </tr>
   <tr>
     <th bgcolor="FFFF00" colspan='3'>Other Equipment:</th> 
   </tr>
    <tr>
     <th>Projector</th><td>:</td><td><input type="text" name="ptr"></td> 
   </tr>
    <tr>
     <th>CCTV</th><td>:</td><td><input type="text" name="cc"></td> 
   </tr>
    <tr>
     <th>AC</th><td>:</td><td><input type="text" name="ak"></td> 
   </tr>
    <tr>
     <th>Printer</th><td>:</td><td><input type="text" name="pi"></td> 
   </tr>
    <tr>
     <th>Fire Extenguisher</th><td>:</td><td><input type="text" name="fe"></td> 
   </tr>

</table>
 <input type="submit" value="Submit"></center>
</form>

</body>
</head>
</html> 


<?php
if(isset($_POST['submit']))
{


$Labname = $_POST["fname"];
$Labno =$_POST["num"];
$labIncharge=$_POST["kal"];

$Contact=$_POST["con"];

$practical=$_POST["pr"];
$trainng=$_POST["tr"];
$dimension=$_POST["di"];

$Computers=$_POST["co"];
$Furniture=$_POST["fu"];
$year=$_POST["yp"];

$cost=$_POST["cp"];
$model=$_POST["pc"];
$processor=$_POST["prh"];

$O.S.=$_POST["os"];
$software=$_POST["as"];
$database=$_POST["db"];
$anti-virus=$_POST["av"];
$Internet=$_POST["ic"];
$LAN:Range=$_POST["ar"];
$Router=$_POST["rss"];
$Projector=$_POST["ptr"];
$CCTV=$_POST["cc"];
$AC=$_POST["ak"];
$Printer=$_POST["pi"];
$FireExtenguisher=$_POST["fe"];

include "connect.php";

$sql = "INSERT INTO form VALUES('$fname','$num','$kal','$con','$pr','$tr','$di','$co','$fu','$yp','$cp','$pc','$prh','$os','$as','$db','$av','$ic','$ar','$rss','$ptr','$cc','$ak','$pi','$fe')";
      
		$result = mysqli_query($con,$sql);
		echo "<h2><font color=green>Successfully added</font></h2>";

}


?>
