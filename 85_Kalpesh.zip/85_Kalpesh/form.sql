-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2017 at 04:57 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kmr`
--

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE IF NOT EXISTS `form` (
  `fname` varchar(10) NOT NULL,
  `num` int(10) NOT NULL,
  `kal` varchar(20) NOT NULL,
  `con` int(10) NOT NULL,
  `pr` varchar(10) NOT NULL,
  `tr` varchar(20) NOT NULL,
  `di` int(30) NOT NULL,
  `co` int(30) NOT NULL,
  `fu` varchar(30) NOT NULL,
  `yp` date NOT NULL,
  `cp` int(50) NOT NULL,
  `pc` varchar(30) NOT NULL,
  `prh` varchar(30) NOT NULL,
  `os` varchar(30) NOT NULL,
  `as` varchar(30) NOT NULL,
  `db` varchar(30) NOT NULL,
  `av` varchar(30) NOT NULL,
  `ic` varchar(20) NOT NULL,
  `ar` varchar(30) NOT NULL,
  `rss` varchar(40) NOT NULL,
  `ptr` varchar(20) NOT NULL,
  `cc` varchar(20) NOT NULL,
  `ak` varchar(20) NOT NULL,
  `pi` varchar(20) NOT NULL,
  `fe` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
